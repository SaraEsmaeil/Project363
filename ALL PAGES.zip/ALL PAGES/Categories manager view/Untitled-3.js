// JavaScript function to handle adding a new category
function addCategory() {
    alert("Add Category functionality to be implemented.");
}

// Add event listener for the add category button
document.querySelector(".btn-add-category").addEventListener("click", addCategory);
