function postAnnouncement() {
    const title = document.getElementById("announcementTitle").value;
    const content = document.getElementById("announcementContent").value;

    if (title && content) {
        alert(`Announcement Posted:\nTitle: ${title}\nContent: ${content}`);
        document.getElementById("announcementTitle").value = "";
        document.getElementById("announcementContent").value = "";
    } else {
        alert("Please enter both title and content for the announcement.");
    }
}
